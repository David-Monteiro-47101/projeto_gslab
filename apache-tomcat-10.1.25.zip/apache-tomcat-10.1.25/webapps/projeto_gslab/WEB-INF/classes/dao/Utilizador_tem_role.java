package dao;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Utilizador_tem_role {
    private String email;
    private String papel;

    public Utilizador_tem_role(String email, String papel) {
        this.email = email;
        this.papel = papel;
    }
    
    public Utilizador_tem_role(ResultSet rs) throws SQLException {
    	this.email = rs.getString("email");
    	this.papel = rs.getString("papel");
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPapel() {
        return papel;
    }

    public void setPapel(String papel) {
        this.papel = papel;
    }
    
    @Override
    public String toString() {
        return "Utilizador_tem_role{" +
                "email='" + email + '\'' +
                ", nome=" + papel +
                '}';
    }
}