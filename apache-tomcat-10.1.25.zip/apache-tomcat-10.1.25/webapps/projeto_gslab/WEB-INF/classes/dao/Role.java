package dao;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Role {
    private String papel;

    public Role(String papel) {
        this.papel = papel;
    }
    
    public Role(ResultSet rs) throws SQLException {
        this.papel = rs.getString("papel");
    }
    
    public String getPapel() {
        return papel;
    }
    
    public void setPapel(String papel) {
        this.papel = papel;
    }
    
    @Override
    public String toString() {
        return "Role{" +
            "papel='" + papel + '\'' +
            '}';
    }
}
