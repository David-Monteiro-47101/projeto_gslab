package coordenador;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import projeto_gslab.DataBaseConfig;

import java.io.IOException;

public class EliminarReservaCalendario extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static DataBaseConfig cp = null;

    public void init() throws ServletException {
        String dbUrl = getServletContext().getInitParameter("db.url");
        String dbUsername = getServletContext().getInitParameter("db.user");
        String dbPass = getServletContext().getInitParameter("db.password");

        Object pool = getServletContext().getAttribute("connPoolId");
        if (pool == null) {
            cp = new DataBaseConfig(dbUrl, dbUsername, dbPass);
            getServletContext().setAttribute("connPoolId", cp);
        } else if(pool instanceof DataBaseConfig) {
            cp = (DataBaseConfig)pool;
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String selectedSlotsString = request.getParameter("selectedSlots");
        System.out.println("Selected slots: " + selectedSlotsString);
        String[] selectedSlots = selectedSlotsString.split(";");

        if (selectedSlots != null) {
            for (String slot : selectedSlots) {
                String[] slotParts = slot.split(",");
                String date = slotParts[0];
                String slotNumber = slotParts[1];

                String query = "DELETE FROM projeto.agendamento WHERE dia = ? AND slot = ?";

				int result = cp.executeUpdate(query, date, slotNumber);
				
				System.out.println("Linhas eliminadas: " + result);
            }
        }

        String sala = request.getParameter("sala");
        response.sendRedirect("CalendarioEliminar?sala=" + sala);
    }
}