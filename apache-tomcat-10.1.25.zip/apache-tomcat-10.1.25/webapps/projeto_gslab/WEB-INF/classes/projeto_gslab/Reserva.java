package projeto_gslab;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class Reserva extends HttpServlet {
	
    private static final long serialVersionUID = 1L;
    private static DataBaseConfig cp = null;

    public void init() throws ServletException {
    	String dbUrl = getServletContext().getInitParameter("db.url");
        String dbUsername = getServletContext().getInitParameter("db.user");
        String dbPass = getServletContext().getInitParameter("db.password");    	
    	
    	Object pool = getServletContext().getAttribute("connPoolId");
    	if ( pool == null) {
            cp = new DataBaseConfig(dbUrl, dbUsername, dbPass);
            getServletContext().setAttribute("connPoolId", cp);
    	} else if(pool instanceof DataBaseConfig) {
    		cp = (DataBaseConfig)pool;	
    	}
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtenção dos parâmetros da requisição
        String sala = request.getParameter("sala");
        String turma = request.getParameter("turma");
        String disciplina = request.getParameter("disciplina");
        String professor = request.getParameter("professor");
        String observacoes = request.getParameter("observacoes");
        String[] selectedSlots = request.getParameterValues("selectedSlots");
        String endDate = request.getParameter("endDate");

        // Obtenção do email do professor da sessão
        String professor_reserva = request.getUserPrincipal().getName();
        
        // Verificação do valor do parâmetro action
        String action = request.getParameter("action");
        System.out.println("Action: " + action);

        List<String> messages = new ArrayList<>(); // Para armazenar mensagens de sucesso/erro

        Connection conn = null;
        try {
            conn = cp.getConnection();
            conn.setAutoCommit(false); // Inicio da transação

            if (action != null) {
                for (String slot : selectedSlots) {
                    String[] slots = slot.split(";");
                    for (String s : slots) {
                        String[] parts = s.split(",");
                        String dia = parts[0];
                        String numeroSlot = parts[1];

                        System.out.println("Dia: " + dia + ", Numero Slot: " + numeroSlot);

                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

                        if ("reserve_only_this".equals(action)) {
                            System.out.println("Entering reserve_only_this block");

                            String query = "INSERT INTO projeto.agendamento (`disciplina`, `turma`, `dia`, `professor`, `observacoes`, `slot`, `sala_nome`, `utilizador_email`)"
                                    + " SELECT ?, ?, ?, ?, ?, ?, ?, ?"
                                    + " WHERE NOT EXISTS ("
                                    + "     SELECT 1 FROM projeto.agendamento"
                                    + "     WHERE `slot` = ? AND `dia` = ? AND `sala_nome` = ?"
                                    + " ) LIMIT 1;";

                            System.out.println("Query: " + query);

                            PreparedStatement pstmt = conn.prepareStatement(query);
                            pstmt.setString(1, disciplina);
                            pstmt.setString(2, turma);
                            pstmt.setString(3, dia);
                            pstmt.setString(4, professor);
                            pstmt.setString(5, observacoes);
                            pstmt.setString(6, numeroSlot);
                            pstmt.setString(7, sala);
                            pstmt.setString(8, professor_reserva);
                            pstmt.setString(9, numeroSlot);
                            pstmt.setString(10, dia);
                            pstmt.setString(11, sala);
                            int rowsAffected = pstmt.executeUpdate();
                            System.out.println("Linhas afetadas: " + rowsAffected);

                            if (rowsAffected == -1) {
                                messages.add("Erro com a base de dados ao tentar reservar: Dia " + dia + ", Slot " + numeroSlot);
                            } else if (rowsAffected == 0) {
                                messages.add("Esse slot já está ocupado: Dia " + dia + ", Slot " + numeroSlot);
                            } else {
                                messages.add("Slot reservado com sucesso: Dia " + dia + ", Slot " + numeroSlot);
                            }
                        } else if ("confirm_reserve".equals(action)) {
                            if (dia != null && !dia.isEmpty() && endDate != null && !endDate.isEmpty()) {
                                LocalDate date1 = LocalDate.parse(dia, formatter);
                                LocalDate date2 = LocalDate.parse(endDate, formatter);
                                long semanasDiferenca = Math.abs(ChronoUnit.WEEKS.between(date1, date2));
                                System.out.println("A diferenca em semanas e: " + semanasDiferenca);

                                LocalDate currentDay = date1;
                                for (int i = 0; i <= semanasDiferenca; i++) {
                                    String diaSemanal = currentDay.format(formatter);

                                    String query = "INSERT INTO projeto.agendamento "
                                            + "(`disciplina`, `turma`, `dia`, `professor`, `observacoes`, `slot`, `sala_nome`, `utilizador_email`)"
                                            + " SELECT ?, ?, ?, ?, ?, ?, ?, ?"
                                            + " WHERE NOT EXISTS ("
                                            + "     SELECT 1 FROM projeto.agendamento"
                                            + "     WHERE `slot` = ? AND `dia` = ? AND `sala_nome` = ?"
                                            + " ) LIMIT 1;";

                                    System.out.println("Query: " + query);

                                    PreparedStatement pstmt = conn.prepareStatement(query);
                                    pstmt.setString(1, disciplina);
                                    pstmt.setString(2, turma);
                                    pstmt.setString(3, diaSemanal);
                                    pstmt.setString(4, professor);
                                    pstmt.setString(5, observacoes);
                                    pstmt.setString(6, numeroSlot);
                                    pstmt.setString(7, sala);
                                    pstmt.setString(8, professor_reserva);
                                    pstmt.setString(9, numeroSlot);
                                    pstmt.setString(10, diaSemanal);
                                    pstmt.setString(11, sala);
                                    int rowsAffected = pstmt.executeUpdate();
                                    System.out.println("Linhas afetadas: " + rowsAffected);

                                    if (rowsAffected == -1) {
                                        messages.add("Erro com a base de dados ao tentar reservar: Dia " + diaSemanal + ", Slot " + numeroSlot);
                                    } else if (rowsAffected == 0) {
                                        messages.add("Esse slot já está ocupado: Dia " + diaSemanal + ", Slot " + numeroSlot);
                                    } else {
                                        messages.add("Slot reservado com sucesso: Dia " + diaSemanal + ", Slot " + numeroSlot);
                                    }

                                    currentDay = currentDay.plusWeeks(1);
                                }
                            } else {
                                messages.add("Dia ou endDate está vazio");
                            }
                        }
                    }
                }
            } else {
                System.out.println("Action is null");
            }

            conn.commit(); // Commit a transação
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Rollback da transação em caso de erro
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        request.getSession().setAttribute("messages", messages);

        response.sendRedirect("ResultadoReserva.jsp");
    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	doGet(request, response);
    }

}