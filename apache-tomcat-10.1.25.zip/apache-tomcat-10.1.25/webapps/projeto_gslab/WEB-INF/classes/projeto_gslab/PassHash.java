package projeto_gslab;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PassHash {
    
    // Converte um array de bytes para uma string hexadecimal
    public static String bytesToHex(byte[] bytes2convert) {
        StringBuilder hexString = new StringBuilder(2 * bytes2convert.length); // StringBuilder para construir a string hexadecimal
        for (byte b : bytes2convert) { // Percorre cada byte do array
            String hex = Integer.toHexString(0xff & b); // Converte o byte para uma string hexadecimal
            if (hex.length() == 1) hexString.append('0'); // Adiciona um zero à esquerda se o hex tiver um dígito
            hexString.append(hex); // Adiciona o valor hexadecimal ao StringBuilder
        }
        return hexString.toString(); // Retorna a string hexadecimal completa
    }

    // Gera um hash SHA-256 a partir de uma string de entrada (senha)
    public static String generateHash(String pass) throws NoSuchAlgorithmException {
        MessageDigest obj = java.security.MessageDigest.getInstance("SHA-256"); // Cria uma instância do algoritmo SHA-256
        obj.update(pass.getBytes()); // Atualiza o objeto MessageDigest com os bytes da string de entrada
        byte[] byteArray = obj.digest(); // Calcula o hash e retorna como um array de bytes
        return bytesToHex(byteArray); // Converte o array de bytes para uma string hexadecimal e retorna
    }

    // Método principal para execução do programa
    public static void main(String[] args) {
        try {
            // Gera o hash da senha "aluno" e imprime em formato hexadecimal
            System.out.println("Data in Hex format : " + generateHash("aluno"));
        } catch (NoSuchAlgorithmException e) {
            // Captura e imprime a stack trace se o algoritmo SHA-256 não for encontrado
            e.printStackTrace();
        }
    }
}
