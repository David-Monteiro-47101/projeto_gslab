package projeto_gslab;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

import dao.Utilizador;

public class Roles extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static DataBaseConfig cp = null;
       
    public void init() throws ServletException {
    	String dbUrl = getServletContext().getInitParameter("db.url");
        String dbUsername = getServletContext().getInitParameter("db.user");
        String dbPass = getServletContext().getInitParameter("db.password");    	
    	
    	Object pool = getServletContext().getAttribute("connPoolId");
    	if ( pool == null) {
            cp = new DataBaseConfig(dbUrl, dbUsername, dbPass);
            getServletContext().setAttribute("connPoolId", cp);
    	} else if(pool instanceof DataBaseConfig) {
    		cp = (DataBaseConfig)pool;	
    	}
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String email = request.getUserPrincipal().getName();
		String query = "SELECT * from PROJETO.UTILIZADOR where email = ?";
		
		ArrayList<Utilizador> utilizadores = cp.selectQuery(query, Utilizador.class, email);
		
		System.out.println(utilizadores);
		
		if(utilizadores.get(0).getIsActive() == true) {
			response.sendRedirect(request.getContextPath() + "/todos/Roles.jsp");
		} else {
			request.getSession().setAttribute("alert", "A sua conta encontra-se desativada");
			response.sendRedirect(request.getContextPath() + "/Departamentos.jsp");
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
