package projeto_gslab;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import dao.Agendamento;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class Calendario extends HttpServlet {
	
    private static final long serialVersionUID = 1L;
    private static DataBaseConfig cp = null;

    public void init() throws ServletException {
    	String dbUrl = getServletContext().getInitParameter("db.url");
        String dbUsername = getServletContext().getInitParameter("db.user");
        String dbPass = getServletContext().getInitParameter("db.password");    	
    	
    	Object pool = getServletContext().getAttribute("connPoolId");
    	if ( pool == null) {
            cp = new DataBaseConfig(dbUrl, dbUsername, dbPass);
            getServletContext().setAttribute("connPoolId", cp);
    	} else if(pool instanceof DataBaseConfig) {
    		cp = (DataBaseConfig)pool;	
    	}
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String sala = request.getParameter("sala");
        request.setAttribute("sala", sala);
        System.out.println("Calendario sala: " + sala);

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        String currentDate = sdf.format(new Date());
        request.setAttribute("data", currentDate);

        response.setContentType("text/html; charset=UTF-8");
        getServletContext().getRequestDispatcher("/todos/CalendarioFinal.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String data = request.getParameter("data");
        String sala = request.getParameter("sala");
        
        System.out.println("Calendario sala: " + sala);
        System.out.println("Calendario data: " + data);
        
        String query = "SELECT * "
                + "FROM projeto.agendamento "
                + "WHERE sala_nome = ? "
                + "AND dia >= DATEADD('DAY', 1 - DAYOFWEEK('" + data +"'), '" + data +"') "
                + "AND dia < DATEADD('DAY', 8 - DAYOFWEEK('" + data +"'), '" + data +"');"; 
        
        ArrayList<Agendamento> agendamentos = cp.selectQuery(query, Agendamento.class, sala);
 
        for (Agendamento agendamento : agendamentos) 
            System.out.println(agendamento);
        
        request.setAttribute("agendamentos", agendamentos);
        request.setAttribute("sala", sala);
        request.setAttribute("data", data); 
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("/todos/CalendarioFinal.jsp");
        dispatcher.forward(request, response);
    }
}