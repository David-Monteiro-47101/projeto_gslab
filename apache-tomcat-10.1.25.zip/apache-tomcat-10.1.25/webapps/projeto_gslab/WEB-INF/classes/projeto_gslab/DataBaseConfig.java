package projeto_gslab;

import java.lang.reflect.Constructor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.h2.jdbcx.JdbcConnectionPool;


public class DataBaseConfig {
	private JdbcConnectionPool cp = null;


	public DataBaseConfig(String dbUrl, String dbUsername, String dbPass) {
		super();
		if(cp == null)
			cp = JdbcConnectionPool.create(dbUrl, dbUsername, dbPass);

	}

	/*
	 * @brief Método genérico para executar uma atualização SQL e retornar o número de linhas afetadas.
	 * 
	 * @param query A atualização SQL a ser executada.
	 * @param params os parâmetros a serem substituídos na atualização SQL
	 * @return o número de linhas afetadas pela operação de atualização
	 */
	public int executeUpdate(String query, Object... params) {
		try (Connection conn = cp.getConnection();
				PreparedStatement stmt = conn.prepareStatement(query)) {
			for (int i = 0; i < params.length; i++) {
				stmt.setObject(i + 1, params[i]);
			}
			int linhasAfetadas = stmt.executeUpdate();
			System.out.println(linhasAfetadas + " linhas afetadas.");
			return linhasAfetadas;
		} catch (SQLException e) {
			System.err.println("Erro ao executar a atualização: " + e.getMessage());
			return -1;
		}
	}

	/*
	 * @brief Método genérico para executar uma consulta SQL e retornar os resultados como uma lista de objetos.
	 * 
	 * @param query A consulta SQL a ser executada.
	 * @param cls A classe que representa o tipo de objeto que será retornado.
	 * @param params os parâmetros a serem substituídos na consulta SQL
	 * @return Uma lista de objetos do tipo especificado.
	 */
	public <T> ArrayList<T> selectQuery(String query, Class<T> cls, Object... params) {
		ArrayList<T> objects = new ArrayList<>();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			conn = cp.getConnection();
			stmt = conn.prepareStatement(query);
			for (int i = 0; i < params.length; i++) {
				stmt.setObject(i + 1, params[i]);
			}

			rs = stmt.executeQuery();
			
			Constructor<T> constructor = cls.getDeclaredConstructor(ResultSet.class);

			while (rs.next()) {
				T object = constructor.newInstance(rs);
				objects.add(object);
			}

		} catch (Exception e) {
			System.err.println("Error ao executar a consulta: " + e.getMessage());
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					System.err.println("Erro ao fechar ResultSet: " + e.getMessage());
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					System.err.println("Erro ao fechar Statement: " + e.getMessage());
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					System.err.println("Erro ao fechar Connection: " + e.getMessage());
				}
			}
		}
		return objects;
	}
	
	/*
	 * @brief método para obter uma ligação com a base de dados.
	 * 
	 * @return uma ligação ativa com a base de dados.
	 * @throws SQLException se ocorrer um erro ao obter a ligação com a base de dados.
	 */
	public Connection getConnection() throws SQLException {
		return cp.getConnection();
	}
}
