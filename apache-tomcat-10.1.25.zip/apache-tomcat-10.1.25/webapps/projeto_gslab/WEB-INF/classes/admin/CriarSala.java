package admin;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import projeto_gslab.DataBaseConfig;

public class CriarSala extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static DataBaseConfig cp = null;

	public void init() throws ServletException {
		String dbUrl = getServletContext().getInitParameter("db.url");
		String dbUsername = getServletContext().getInitParameter("db.user");
		String dbPass = getServletContext().getInitParameter("db.password");    	

		Object pool = getServletContext().getAttribute("connPoolId");
		if ( pool == null) {
			cp = new DataBaseConfig(dbUrl, dbUsername, dbPass);
			getServletContext().setAttribute("connPoolId", cp);
		} else if(pool instanceof DataBaseConfig) {
			cp = (DataBaseConfig)pool;	
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getUserPrincipal().getName();

		String nome = request.getParameter("nome");
		String localizacao = request.getParameter("localizacao");

		String capacidadeString = request.getParameter("capacidade");
		Integer capacidade = null; // Usamos Integer em vez de int para permitir null

		if (capacidadeString != null && !capacidadeString.isEmpty()) {
			capacidade = Integer.parseInt(capacidadeString);
		}

		String insertQuery = "INSERT INTO projeto.sala (nome, capacidade, localizacao, email_utilizador) "
				+ "SELECT ?, ?, ?, ? "
				+ "WHERE NOT EXISTS (SELECT 1 FROM projeto.sala WHERE nome = ?) LIMIT 1;";

		int rowsAffected = cp.executeUpdate(insertQuery, nome, capacidade, localizacao, email, nome);
		
		if (rowsAffected <= 0) {
			System.out.println("Uma sala com esse nome já existe: " + nome);
			request.getSession().setAttribute("alert", "Uma sala com esse nome já existe.");
		} else {
			System.out.println("Sala adicionada com sucesso: " + nome);
			request.getSession().setAttribute("alert", "Sala adicionada com sucesso.");
		}

		response.setContentType("text/html; charset=UTF-8");
		response.sendRedirect(request.getContextPath() + "/admin/Admin.jsp");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
