package admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import projeto_gslab.DataBaseConfig;

import java.io.IOException;
import java.util.ArrayList;

import dao.Utilizador;

public class DesativarAtivarUtilizador extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static DataBaseConfig cp = null;

    public void init() throws ServletException {
    	String dbUrl = getServletContext().getInitParameter("db.url");
        String dbUsername = getServletContext().getInitParameter("db.user");
        String dbPass = getServletContext().getInitParameter("db.password");    	
    	
    	Object pool = getServletContext().getAttribute("connPoolId");
    	if ( pool == null) {
            cp = new DataBaseConfig(dbUrl, dbUsername, dbPass);
            getServletContext().setAttribute("connPoolId", cp);
    	} else if(pool instanceof DataBaseConfig) {
    		cp = (DataBaseConfig)pool;	
    	}
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String query = "SELECT * FROM projeto.utilizador;"; 
        ArrayList<Utilizador> utilizadores = cp.selectQuery(query, Utilizador.class);
        
        for (Utilizador utilizador : utilizadores) 
            System.out.println(utilizador);

        request.setAttribute("utilizadores", utilizadores);
        
        response.setContentType("text/html; charset=UTF-8");
        getServletContext().getRequestDispatcher("/admin/DesativarAtivarUtilizador.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String action = request.getParameter("action");
		System.out.println("utilizador: " + email);
		
		if (email != null && action != null) {
            boolean isActive = "ativar".equals(action);
            String updateQuery = "UPDATE projeto.utilizador SET is_active = ? WHERE email = ?;";
            
            cp.executeUpdate(updateQuery, isActive, email);
            
        }
		doGet(request, response);
	}

}
