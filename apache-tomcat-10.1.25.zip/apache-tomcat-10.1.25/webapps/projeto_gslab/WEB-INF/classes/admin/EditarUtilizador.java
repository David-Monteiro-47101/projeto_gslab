package admin;

import java.io.IOException;
import java.util.ArrayList;

import dao.Utilizador;
import dao.Utilizador_tem_role;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import projeto_gslab.DataBaseConfig;


public class EditarUtilizador extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static DataBaseConfig cp = null;

    public void init() {
        String dbUrl = getServletContext().getInitParameter("db.url");
        String dbUsername = getServletContext().getInitParameter("db.user");
        String dbPass = getServletContext().getInitParameter("db.password");

        Object pool = getServletContext().getAttribute("connPoolId");
        if ( pool == null) {
            cp = new DataBaseConfig(dbUrl, dbUsername, dbPass);
            getServletContext().setAttribute("connPoolId", cp);
        }else if(pool instanceof DataBaseConfig) {
            cp = (DataBaseConfig)pool;
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String email = request.getParameter("Utilizador");
        System.out.println("email: " + email);
        
        String query = "SELECT * FROM projeto.utilizador WHERE email = ? ;";
        ArrayList<Utilizador> utilizador = cp.selectQuery(query, Utilizador.class, email);

        HttpSession sessionEditarUtilizador = request.getSession();
        sessionEditarUtilizador.setAttribute("email", email);
        sessionEditarUtilizador.setAttribute("active", utilizador.get(0).getIsActive());
        
        System.out.println(utilizador.get(0).getIsActive());
        
        request.setAttribute("utilizador", utilizador);
       
        
        String query2 = "SELECT * FROM projeto.utilizador_tem_role t INNER JOIN projeto.role r ON t.papel = r.papel WHERE t.email = ? ;";

        ArrayList<Utilizador_tem_role> roles = cp.selectQuery(query2, Utilizador_tem_role.class, email);
        
        request.setAttribute("roles", roles);

        if (!utilizador.isEmpty()) {
            System.out.println("nome: " + utilizador.get(0).getNome());
            System.out.println("email: " + utilizador.get(0).getEmail());
            System.out.println("password: " + utilizador.get(0).getPassword());
        } else {
            System.out.println("Não foi encontrado nenhum utilizador com email.");
        }

        if (!roles.isEmpty()) {
            System.out.println("roles: " + roles);
        } else {
            System.out.println("O utilizador não tem papéis.");
        }

        response.setContentType("text/html; charset=UTF-8");
        getServletContext().getRequestDispatcher("/admin/EditarUtilizador.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}