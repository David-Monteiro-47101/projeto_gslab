package admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import projeto_gslab.DataBaseConfig;

import java.io.IOException;
import java.util.ArrayList;

import dao.Sala;

public class DesativarAtivarSala extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static DataBaseConfig cp = null;

    public void init() throws ServletException {
    	String dbUrl = getServletContext().getInitParameter("db.url");
        String dbUsername = getServletContext().getInitParameter("db.user");
        String dbPass = getServletContext().getInitParameter("db.password");    	
    	
    	Object pool = getServletContext().getAttribute("connPoolId");
    	if ( pool == null) {
            cp = new DataBaseConfig(dbUrl, dbUsername, dbPass);
            getServletContext().setAttribute("connPoolId", cp);
    	} else if(pool instanceof DataBaseConfig) {
    		cp = (DataBaseConfig)pool;	
    	}
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String query = "SELECT * FROM projeto.sala;"; 
        ArrayList<Sala> salas = cp.selectQuery(query, Sala.class);
        
        for (Sala sala : salas) 
            System.out.println(sala);

        request.setAttribute("salas", salas);
        
        response.setContentType("text/html; charset=UTF-8");
        getServletContext().getRequestDispatcher("/admin/DesativarAtivarSala.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String sala = request.getParameter("sala");
        String action = request.getParameter("action");
		System.out.println("sala: " + sala);
				
		if (sala != null && action != null) {
			
			boolean isActive = "ativar".equals(action);	
            String updateQuery = "UPDATE projeto.sala SET is_active = ? WHERE nome = ?;";

            cp.executeUpdate(updateQuery, isActive, sala);
        }
		doGet(request, response);
	}

}