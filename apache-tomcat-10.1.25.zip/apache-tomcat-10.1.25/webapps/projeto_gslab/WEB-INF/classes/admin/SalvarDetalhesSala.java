package admin;

import java.io.IOException;
import java.util.ArrayList;

import dao.Sala;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import projeto_gslab.DataBaseConfig;

public class SalvarDetalhesSala extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static DataBaseConfig cp = null;

	public void init() throws ServletException {
		String dbUrl = getServletContext().getInitParameter("db.url");
		String dbUsername = getServletContext().getInitParameter("db.user");
		String dbPass = getServletContext().getInitParameter("db.password");    	

		Object pool = getServletContext().getAttribute("connPoolId");
		if ( pool == null) {
			cp = new DataBaseConfig(dbUrl, dbUsername, dbPass);
			getServletContext().setAttribute("connPoolId", cp);
		} else if(pool instanceof DataBaseConfig) {
			cp = (DataBaseConfig)pool;	
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String newName = request.getParameter("newName");
		String location = request.getParameter("location");
		String capacidadeString = request.getParameter("capacity");
		Integer capacity = null; // Usamos Integer em vez de int para permitir null

		if (capacidadeString != null && !capacidadeString.isEmpty()) {
			capacity = Integer.parseInt(capacidadeString);
		}

		HttpSession sessionEditarSala = request.getSession();
		String name = (String) sessionEditarSala.getAttribute("name");
		Boolean active = (Boolean) sessionEditarSala.getAttribute("active");
		String emailUtilizador = (String) sessionEditarSala.getAttribute("emailUtilizador");

		System.out.println("newName: " + newName);
		System.out.println("name: " + name);
		System.out.println("location: " + location);
		System.out.println("capacity: " + capacity);

		if (isSalaInUse(newName) && !name.equals(newName)) {
			System.out.println("Uma sala com esse nome já existe: " + name);
			request.getSession().setAttribute("alert", "Uma sala com esse nome já existe.");
			response.setContentType("text/html; charset=UTF-8");
			response.sendRedirect(request.getContextPath() + "/admin/Admin.jsp");
			return;
		}

		try {       
			String queryInsertNewSala = "INSERT INTO projeto.sala(nome, capacidade, localizacao, email_utilizador, is_active) VALUES ( ?, ?, ?, ?, ?);"; 

			int rowsAffected = cp.executeUpdate(queryInsertNewSala, newName, capacity, location, emailUtilizador, active);

			String updateAgendamentoQuery = "UPDATE projeto.agendamento SET SALA_NOME = ? WHERE SALA_NOME = ?;";
			cp.executeUpdate(updateAgendamentoQuery, newName, name);

			String queryDeleteOldSala = "DELETE FROM projeto.sala WHERE NOME = ?;";
			cp.executeUpdate(queryDeleteOldSala, name);

			if (rowsAffected == 0) {
				System.out.println("Erro: " + name);
				request.getSession().setAttribute("alert", "Erro ao inserir a nova sala:");
			} else {
				System.out.println("Sala editada com sucesso: " + name);
				request.getSession().setAttribute("alert", "Sala editada com sucesso.");
			}

		} catch (Exception e) {
			System.err.println("Erro ao executar a atualização: " + e.getMessage());
			request.getSession().setAttribute("alert", "Erro ao editar a sala.");
			e.printStackTrace();
		}

		response.setContentType("text/html; charset=UTF-8");
		response.sendRedirect(request.getContextPath() + "/admin/Admin.jsp");

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	/*
	 * @brief verifica se um determinado nome de sala já está em uso por alguma sala existente na base de dados.
	 * 
	 * @param newSalaName o nome da sala a ser verificado.
	 * @return true se o nome da sala já estiver em uso, false caso contrário.
	 */
	private boolean isSalaInUse(String newSalaName) {
		String query = "SELECT * FROM projeto.sala WHERE nome = '" + newSalaName + "'"; 
		ArrayList<Sala> salas = cp.selectQuery(query, Sala.class);

		return !salas.isEmpty();
	}
	
}