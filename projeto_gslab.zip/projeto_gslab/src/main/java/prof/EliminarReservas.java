package prof;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import projeto_gslab.DataBaseConfig;

import java.io.IOException;
import java.util.ArrayList;

import dao.Agendamento;

public class EliminarReservas extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static DataBaseConfig cp = null;

    public void init() throws ServletException {
    	String dbUrl = getServletContext().getInitParameter("db.url");
        String dbUsername = getServletContext().getInitParameter("db.user");
        String dbPass = getServletContext().getInitParameter("db.password");    	
    	
    	Object pool = getServletContext().getAttribute("connPoolId");
    	if ( pool == null) {
            cp = new DataBaseConfig(dbUrl, dbUsername, dbPass);
            getServletContext().setAttribute("connPoolId", cp);
    	} else if(pool instanceof DataBaseConfig) {
    		cp = (DataBaseConfig)pool;	
    	}
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String professor_reserva = request.getUserPrincipal().getName();
        System.out.println("Professor Reserva: " + professor_reserva);
        
        String query = "SELECT * FROM projeto.agendamento WHERE utilizador_email = ?;"; 
        ArrayList<Agendamento> agendamentos = cp.selectQuery(query, Agendamento.class, professor_reserva);
        
        for (Agendamento agendamento : agendamentos) 
            System.out.println(agendamento);

        request.setAttribute("agendamentos", agendamentos);
        
        
        response.setContentType("text/html; charset=UTF-8");
        getServletContext().getRequestDispatcher("/todos/EliminarReservas.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String AgendamentoId = request.getParameter("AgendamentoId");
		System.out.println("AgendamentoId: " + AgendamentoId);
        if (AgendamentoId != null) {
            String deleteQuery = "DELETE FROM projeto.agendamento WHERE id_agendamento = ?;";
            cp.executeUpdate(deleteQuery, AgendamentoId);
        }
		doGet(request, response);
	}

}