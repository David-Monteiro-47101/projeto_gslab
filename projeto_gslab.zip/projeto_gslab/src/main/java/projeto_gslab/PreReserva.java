package projeto_gslab;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class PreReserva extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String sala = request.getParameter("sala");
	    String selectedSlots = request.getParameter("selectedSlots");

	    if (selectedSlots != null) {
	        String[] slots = selectedSlots.split(";");

	        for (String slot : slots) {
	            String[] parts = slot.split(",");
	            String day = parts[0];
	            String position = parts[1];

	            System.out.println("Dia: " + day + " Slot: " + position);
	        }
	    }

	    request.setAttribute("sala", sala);
	    request.setAttribute("selectedSlots", selectedSlots);

	    response.setContentType("text/html; charset=UTF-8");
	    getServletContext().getRequestDispatcher("/todos/Reserva.jsp").forward(request, response);
	}
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

}
