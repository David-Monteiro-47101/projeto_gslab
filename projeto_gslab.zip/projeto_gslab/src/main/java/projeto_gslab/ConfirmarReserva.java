package projeto_gslab;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ConfirmarReserva extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    	String sala = request.getParameter("sala");
        String[] selectedSlots = request.getParameterValues("selectedSlots");

        List<String> slotStatus = new ArrayList<>();
        for (String slot : selectedSlots) {
            slotStatus.add(slot + ": Free");
        }

        HttpSession session = request.getSession();
        session.setAttribute("slotStatus", slotStatus);
        session.setAttribute("sala", sala);
        System.out.println(sala);

        request.getRequestDispatcher("/todos/ConfirmarReserva.jsp").forward(request, response);
    }
}