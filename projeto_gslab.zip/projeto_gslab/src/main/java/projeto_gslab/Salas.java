package projeto_gslab;

import java.io.IOException;
import java.util.ArrayList;


import dao.Sala;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class Salas extends HttpServlet {
	
    private static final long serialVersionUID = 1L;
    private static DataBaseConfig cp = null;

    public void init() throws ServletException {
    	String dbUrl = getServletContext().getInitParameter("db.url");
        String dbUsername = getServletContext().getInitParameter("db.user");
        String dbPass = getServletContext().getInitParameter("db.password");    	
    	
    	Object pool = getServletContext().getAttribute("connPoolId");
    	if ( pool == null) {
            cp = new DataBaseConfig(dbUrl, dbUsername, dbPass);
            getServletContext().setAttribute("connPoolId", cp);
    	} else if(pool instanceof DataBaseConfig) {
    		cp = (DataBaseConfig)pool;	
    	}
    }
       
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
        HttpSession login_salas_session = request.getSession();
        String email = (String) login_salas_session.getAttribute("email");
        login_salas_session.setAttribute("email", email);
        System.out.println("Professor Reserva: " + email);
    	
        String query = "SELECT * FROM projeto.sala WHERE is_active = true"; 
        ArrayList<Sala> salas = cp.selectQuery(query, Sala.class);
        
        for (Sala sala : salas) 
            System.out.println(sala);

        request.setAttribute("salas", salas);
        
        response.setContentType("text/html; charset=UTF-8");
        getServletContext().getRequestDispatcher("/todos/Salas.jsp").forward(request, response);
        
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}

