package coordenador;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.Part;
import projeto_gslab.DataBaseConfig;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

@MultipartConfig
public class InsertJSON extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static DataBaseConfig cp = null;

	public void init() throws ServletException {
		String dbUrl = getServletContext().getInitParameter("db.url");
		String dbUsername = getServletContext().getInitParameter("db.user");
		String dbPass = getServletContext().getInitParameter("db.password");

		Object pool = getServletContext().getAttribute("connPoolId");
		if (pool == null) {
			cp = new DataBaseConfig(dbUrl, dbUsername, dbPass);
			getServletContext().setAttribute("connPoolId", cp);
		} else if (pool instanceof DataBaseConfig) {
			cp = (DataBaseConfig) pool;
		}
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		boolean success = true;
		String message = "JSON data inserted successfully.";

		try {
			Part filePart = req.getPart("jsonFile");
			InputStream fileContent = filePart.getInputStream();
			String content = new Scanner(fileContent, StandardCharsets.UTF_8.name()).useDelimiter("\\A").next();
			JSONObject jsonObject = new JSONObject(content);

			// Insert Utilizador
			if (jsonObject.has("Utilizador")) {
				JSONArray utilizadorArray = jsonObject.getJSONArray("Utilizador");
				for (int i = 0; i < utilizadorArray.length(); i++) {
					JSONObject utilizador = utilizadorArray.getJSONObject(i);
					String utilizadorQuery = "INSERT INTO projeto.Utilizador (email, nome, password) VALUES (?, ?, ?)";

					cp.executeUpdate(utilizadorQuery, utilizador.getString("email"), utilizador.getString("nome"), utilizador.getString("password"));

				}
			}

			// Insert Role
			if (jsonObject.has("Role")) {
				JSONArray roleArray = jsonObject.getJSONArray("Role");
				for (int i = 0; i < roleArray.length(); i++) {
					JSONObject role = roleArray.getJSONObject(i);
					String roleQuery = "INSERT INTO projeto.Role (papel) VALUES (?)";

					cp.executeUpdate(roleQuery, role.getString("papel"));

				}
			}

			// Insert Utilizador_tem_role
			if (jsonObject.has("Utilizador_tem_role")) {
				JSONArray temArray = jsonObject.getJSONArray("Utilizador_tem_role");
				for (int i = 0; i < temArray.length(); i++) {
					JSONObject tem = temArray.getJSONObject(i);
					String utilizadoreRoleQuery = "INSERT INTO projeto.Utilizador_tem_role (email, papel) VALUES (?, ?)";

					cp.executeUpdate(utilizadoreRoleQuery, tem.getString("email"), tem.getString("papel"));
				}
			}

			// Insert Sala
			if (jsonObject.has("Sala")) {
				JSONArray salaArray = jsonObject.getJSONArray("Sala");
				for (int i = 0; i < salaArray.length(); i++) {
					JSONObject sala = salaArray.getJSONObject(i);
					String salaQuery = "INSERT INTO projeto.Sala (nome, capacidade, localizacao, EMAIL_UTILIZADOR) VALUES (?, ?, ?, ?)";

					cp.executeUpdate(salaQuery, sala.getString("nome"), sala.getInt("capacidade"), sala.getString("localizacao"), sala.getString("email"));
				}
			}

			// Insert Agendamento
			if (jsonObject.has("Agendamento")) {
				JSONArray agendamentoArray = jsonObject.getJSONArray("Agendamento");
				for (int i = 0; i < agendamentoArray.length(); i++) {
					JSONObject agendamento = agendamentoArray.getJSONObject(i);
					String agendamentoQuery = "INSERT INTO projeto.Agendamento (disciplina, turma, slot, dia, professor, observacoes, SALA_NOME, UTILIZADOR_EMAIL) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

					LocalDate diaInicio = LocalDate.parse(agendamento.getString("diaInicio"));
					LocalDate diaFinal = LocalDate.parse(agendamento.getString("diaFinal"));
					int slotInicio = agendamento.getInt("slotInicio");
					int slotFinal = agendamento.getInt("slotFinal");

					long weeks = ChronoUnit.WEEKS.between(diaInicio, diaFinal);

					for (int j = 0; j <= weeks; j++) {
						LocalDate diaAgendamento = diaInicio.plusWeeks(j);

						for (int slot = slotInicio; slot <= slotFinal; slot++) {
							cp.executeUpdate(agendamentoQuery, agendamento.getString("disciplina"), agendamento.getString("turma") , slot, diaAgendamento.toString(), agendamento.getString("professor"), agendamento.getString("observacoes"), agendamento.getString("SALA_NOME"), agendamento.getString("UTILIZADOR_EMAIL"));
						}
					}
				}
			}

		} catch (Exception e) {
			success = false;
			message = "Error inserting JSON data: " + e.getMessage();
		}

		resp.sendRedirect(req.getContextPath() + "/todos/jsoninsert.jsp?success=" + success + "&message=" + java.net.URLEncoder.encode(message, "UTF-8"));
	}
}
