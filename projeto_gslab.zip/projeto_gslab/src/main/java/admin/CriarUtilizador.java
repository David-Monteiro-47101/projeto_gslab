package admin;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import projeto_gslab.DataBaseConfig;
import projeto_gslab.PassHash;

public class CriarUtilizador extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static DataBaseConfig cp = null;

	public void init() throws ServletException {
		String dbUrl = getServletContext().getInitParameter("db.url");
		String dbUsername = getServletContext().getInitParameter("db.user");
		String dbPass = getServletContext().getInitParameter("db.password");     

		Object pool = getServletContext().getAttribute("connPoolId");
		if (pool == null) {
			cp = new DataBaseConfig(dbUrl, dbUsername, dbPass);
			getServletContext().setAttribute("connPoolId", cp);
		} else if (pool instanceof DataBaseConfig) {
			cp = (DataBaseConfig) pool;    
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nome = request.getParameter("nome");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String[] roles = request.getParameterValues("role[]");

		try {
			// Calcular o hash da senha
			String hashedPassword = PassHash.generateHash(password);

			// Query para inserir utilizador apenas se o email já nao existir
			String insertUserQuery = "INSERT INTO projeto.utilizador(email, nome, password) " +
									 "SELECT ?, ?, ? " +
									 "WHERE NOT EXISTS (SELECT email FROM projeto.utilizador WHERE email = ?) LIMIT 1";

			int rowsAffected = cp.executeUpdate(insertUserQuery, email, nome, hashedPassword, email);

			if (rowsAffected <= 0) {
				System.out.println("Um utilizador com esse email já existe: " + email);
				request.getSession().setAttribute("alert", "Um utilizador com esse email já existe.");
			} else {
				System.out.println("Utilizador adicionado com sucesso: " + email);
				request.getSession().setAttribute("alert", "Utilizador adicionado com sucesso.");

				// Inserir papeis quando a criação do utilizador for bem sucedida
				if (roles != null && roles.length > 0) {
					String insertRoleQuery = "INSERT INTO projeto.utilizador_tem_role(email, papel) VALUES (?, ?)";
					for (String role : roles) {
						cp.executeUpdate(insertRoleQuery, email, role);
					}
				}
			}
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			request.getSession().setAttribute("alert", "Erro ao criar o hash da senha.");
		}

		response.setContentType("text/html; charset=UTF-8");
		response.sendRedirect(request.getContextPath() + "/admin/Admin.jsp");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
