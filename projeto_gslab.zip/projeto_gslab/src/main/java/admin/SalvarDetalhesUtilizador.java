package admin;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;

import dao.Utilizador;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import projeto_gslab.DataBaseConfig;
import projeto_gslab.PassHash;



public class SalvarDetalhesUtilizador extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static DataBaseConfig cp = null;

	public void init() throws ServletException {
		String dbUrl = getServletContext().getInitParameter("db.url");
		String dbUsername = getServletContext().getInitParameter("db.user");
		String dbPass = getServletContext().getInitParameter("db.password");    	

		Object pool = getServletContext().getAttribute("connPoolId");
		if ( pool == null) {
			cp = new DataBaseConfig(dbUrl, dbUsername, dbPass);
			getServletContext().setAttribute("connPoolId", cp);
		} else if(pool instanceof DataBaseConfig) {
			cp = (DataBaseConfig)pool;	
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String name = request.getParameter("newName");
		String newEmail = request.getParameter("newEmail");
		String password = request.getParameter("password");
		String[] role = request.getParameterValues("role");

		HttpSession sessionEditarUtilizador = request.getSession();
		String email = (String) sessionEditarUtilizador.getAttribute("email");
		Boolean active = (Boolean) sessionEditarUtilizador.getAttribute("active");

		System.out.println("name: " + name);
		System.out.println("email: " + email);
		System.out.println("newEmail: " + newEmail);
		System.out.println("password: " + password);
		System.out.println("Is active: " + active);
		System.out.println("role: " + Arrays.toString(role));

		String hashedPassword = null;

		try {
			hashedPassword = PassHash.generateHash(password);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		if (isUsernameInUse(newEmail) && !email.equals(newEmail)) {
			System.out.println("Um Utilizador com esse email já existe: " + newEmail);
			request.getSession().setAttribute("alert", "Um Utilizador com esse email já existe.");
			response.setContentType("text/html; charset=UTF-8");
			response.sendRedirect(request.getContextPath() + "/admin/Admin.jsp");
			return; 
		}

		try {
			String deleteQueryRoles = "DELETE FROM projeto.utilizador_tem_role WHERE email = ?;";
			cp.executeUpdate(deleteQueryRoles, email);

			if(!email.equals(newEmail)) {  
				String queryInsertNewUser = "INSERT INTO projeto.Utilizador(email, nome, password, is_active) VALUES ( ?, ?, ?, ?);";
				cp.executeUpdate(queryInsertNewUser, newEmail, name, hashedPassword, active);
				
			} else {
				String queryUpdateUser = "UPDATE projeto.Utilizador SET nome = ? , password = ? , is_active = ? WHERE email = ?;";
				cp.executeUpdate(queryUpdateUser, name, hashedPassword, active, newEmail);
			}


			if(role != null) {
				for (String papel : role) {
					String insertRoleQuery = "INSERT INTO projeto.utilizador_tem_role (email, papel) VALUES ( ?, ?);";
					cp.executeUpdate(insertRoleQuery, newEmail, papel);
				}
			}

			String updateSalaQuery = "UPDATE projeto.sala SET email_utilizador = ? WHERE email_utilizador = ?;";
			int rowsAffected1 = cp.executeUpdate(updateSalaQuery, newEmail, email);

			String updateAgendamentoQuery = "UPDATE projeto.agendamento SET UTILIZADOR_EMAIL = ? WHERE UTILIZADOR_EMAIL = ?;";
			int rowsAffected2 = cp.executeUpdate(updateAgendamentoQuery, newEmail, email);

			if(!email.equals(newEmail)) {
				String queryDeleteOldUser = "DELETE FROM projeto.utilizador WHERE email = ?;";
				cp.executeUpdate(queryDeleteOldUser, email);
			}

			if (rowsAffected1 < 0 || rowsAffected2 < 0) {
				System.out.println("Erro: " + name);
				request.getSession().setAttribute("alert", "Erro ao atualizar os agendamentos e salas:");
			} else {
				System.out.println("Utilizador editado com sucesso: " + name);
				request.getSession().setAttribute("alert", "Utilizador editado com sucesso.");
			}

		} catch (Exception e){
			System.err.println("Erro ao executar a atualização: " + e.getMessage());
			request.getSession().setAttribute("alert", "Erro ao editar o utilizador.");
			e.printStackTrace();
		}

		response.setContentType("text/html; charset=UTF-8");
		response.sendRedirect(request.getContextPath() + "/admin/Admin.jsp");

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	/*
	 * @brief verifica se um determinado email já está em uso por algum utilizador existente na base de dados.
	 * 
	 * @param newEmail o email a ser verificado.
	 * @return true se o email já estiver em uso, false caso contrário.
	 */
	private boolean isUsernameInUse(String newEmail) { 
		String query = "SELECT * FROM projeto.utilizador WHERE email = '" + newEmail + "'"; 
		ArrayList<Utilizador> utilizadores = cp.selectQuery(query, Utilizador.class);

		return !utilizadores.isEmpty();
	}

}