package dao;


import java.sql.ResultSet;
import java.sql.SQLException;

public class Utilizador {
    private String email;
    private String nome;
    private String password;
    private Boolean is_active;

    public Utilizador(String email, String nome, String password, Boolean is_active) {
        this.email = email;
        this.nome = nome;
        this.password = password;
        this.is_active = is_active;
    }
    
    public Utilizador(ResultSet rs) throws SQLException {
    	this.email = rs.getString("email");
    	this.nome = rs.getString("nome");
    	this.password = rs.getString("password");
    	this.is_active = rs.getBoolean("is_active");
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public Boolean getIsActive() {
        return is_active;
    }
    
    public void setIsActive(Boolean is_active) {
        this.is_active = is_active;
    }

    @Override
    public String toString() {
        return "Utilizador{" +
                "email='" + email + '\'' +
                ", nome=" + nome +
                ", password='" + password + '\'' +
                ", is_active='" + is_active + '\'' +
                '}';
    }
}
